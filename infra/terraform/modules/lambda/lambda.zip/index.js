"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({});
const dynamo = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const TABLE_NAME = process.env.DYNAMODB_TABLE_NAME ?? "";
const validateInput = (body) => {
    if (!body.name?.trim() ||
        !body.diagnosisTime?.trim() ||
        !body.treatmentType?.trim() ||
        !body.basalInsulin?.trim()) {
        return false;
    }
    if (!Number.isFinite(body.insulinCarboRatio) ||
        !Number.isFinite(body.insulinSensitivity) ||
        !Number.isFinite(body.age) ||
        !Number.isFinite(body.carboDayGoal) ||
        !Number.isFinite(body.targetGlucose)) {
        return false;
    }
    return true;
};
const handler = async (event) => {
    try {
        console.log("Received event: ", JSON.stringify(event));
        const sub = event.requestContext.authorizer.jwt.claims.sub;
        if (!sub || typeof sub !== "string") {
            return {
                statusCode: 401,
                body: JSON.stringify({
                    message: "Unauthorized."
                })
            };
        }
        if (!event.body) {
            return {
                statusCode: 400,
                body: JSON.stringify({
                    message: "Request body is not sent."
                })
            };
        }
        const body = JSON.parse(event.body);
        if (!validateInput(body)) {
            return {
                statusCode: 400,
                body: JSON.stringify({
                    message: "Invalid request data."
                })
            };
        }
        const now = new Date().toISOString();
        await dynamo.send(new lib_dynamodb_1.PutCommand({
            TableName: TABLE_NAME,
            Item: {
                PK: `USER#${sub}`,
                SK: "PROFILE",
                ...body,
                createdAt: now,
                updatedAt: now
            }
        }));
        return {
            statusCode: 201,
            body: JSON.stringify({
                message: "Profile created successfully."
            })
        };
    }
    catch (error) {
        console.error("Unexpected error: ", error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Internal server error."
            })
        };
    }
};
exports.handler = handler;
